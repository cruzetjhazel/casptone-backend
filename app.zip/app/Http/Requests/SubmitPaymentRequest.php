<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SubmitPaymentRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'plan' => ['required', Rule::in(['half', 'full'])],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'reference_number' => ['required', 'string', 'max:255'],
            'payer_name' => ['required', 'string', 'max:150'],
            'payment_date' => ['required', 'date_format:Y-m-d', 'before_or_equal:today'],
        ];
    }
}