<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PhotographerPublicProfileResource;
use App\Models\User;
use App\Models\FavoritePhotographer;
use App\Models\ProfileView;
use App\Traits\ApiResponses;
use Illuminate\Http\Request;
use App\Services\Photographer\BookabilityService;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class PublicPhotographerController extends Controller
{
    use ApiResponses;

    public function index(\Illuminate\Http\Request $request, BookabilityService $bookabilityService)
    {
        $request->validate(['date' => ['nullable', 'date_format:Y-m-d']]);

        $photographers = User::query()
            ->where('account_type', \App\Enums\AccountType::Photographer)
            ->whereHas('photographerApplication', fn ($q) =>
                $q->where('status', \App\Enums\PhotographerApplicationStatus::Approved)
            )
            ->when($request->filled('date'), function ($query) use ($request) {
                $date = $request->query('date');
                $query->whereDoesntHave('blockedDates', fn ($q) =>
                    $q->where('date', $date)->whereNull('start_time')
                );
            })
            ->withCount([
                'favoritePhotographers as favorites_count',
                'bookingsAsPhotographer as bookings_count',
                'reviews as reviews_count',
                'bookingsAsPhotographer as completed_bookings_count' => fn ($q) =>
                    $q->where('status', \App\Enums\BookingStatus::Completed),
            ])
            ->withAvg('reviews', 'rating')
            ->with([
                'photographerProfile',
                'photographerApplication',
                'portfolioImages',
                'packages',
                'addOns',
                'paymentConfig',
                'reviews.client',
            ])
            ->get()
            ->filter(fn ($photographer) => $bookabilityService->isBookable($photographer))
            ->sort(fn ($a, $b) => $this->recommendedKey($b) <=> $this->recommendedKey($a))
            ->values();

        return $this->success(PhotographerPublicProfileResource::collection($photographers));
    }

    /**
     * Stable "Recommended" ranking key. Compared descending, so the last
     * element is -id: ties fall back to the lowest photographer ID first.
     * (Bookable-first is already enforced by the isBookable() filter.)
     */
    private function recommendedKey(User $p): array
    {
        return [
            $p->packages->where('status', \App\Enums\PackageStatus::Published)->count(), // 2. active packages
            $p->portfolioImages->where('status', \App\Enums\PortfolioImageStatus::Active)->count()
                + ($p->addOns->where('status', \App\Enums\AddOnStatus::Active)->isNotEmpty() ? 3 : 0)
                + (filled($p->photographerProfile?->bio) ? 2 : 0), // 3. completeness
            round((float) ($p->reviews_avg_rating ?? 0), 2),   // 4. rating
            (int) ($p->reviews_count ?? 0),                    //    review count
            (int) ($p->completed_bookings_count ?? 0),         // 5. completed bookings
            -$p->id,                                           // 6. tie-breaker
        ];
    }

    public function show(Request $request, User $user)
    {
        // A suspended/deactivated photographer must 404 here exactly like an
        // unapproved one — otherwise their profile stays reachable by direct
        // URL even though index()/featured() correctly hide them (both are
        // filtered through BookabilityService::isBookable(), which also
        // checks account_status). Do not drop this check again.
        if (
            ! $user->isPhotographer()
            || ! $user->isApprovedPhotographer()
            || $user->account_status !== \App\Enums\AccountStatus::Active
        ) {
            throw new NotFoundHttpException('Photographer profile not found.');
        }

        $this->logProfileView($request, $user);

        $user->load([
            'photographerProfile',
            'photographerApplication',
            'portfolioImages',
            'packages',
            'addOns',
            'reviews.client',
        ]);
        $user->loadCount('reviews');
        $user->loadAvg('reviews', 'rating');

        return $this->success(new PhotographerPublicProfileResource($user));
    }

    /**
     * Records a profile view, deduped to once per visitor per day (§ dedupe
     * key = photographer + viewer_hash + viewed_on, unique-constrained).
     * Skips logging when a photographer views their own profile.
     */
    private function logProfileView(Request $request, User $photographer): void
    {
        $viewer = $request->user();

        if ($viewer && $viewer->id === $photographer->id) {
            return;
        }

        $identity = $viewer
            ? "user:{$viewer->id}"
            : 'ip:'.$request->ip().'|ua:'.substr((string) $request->userAgent(), 0, 150);

        ProfileView::firstOrCreate([
            'photographer_id' => $photographer->id,
            'viewer_hash' => hash('sha256', $identity),
            'viewed_on' => now()->toDateString(),
        ]);
    }

    public function featured(BookabilityService $bookabilityService)
    {
        $photographers = User::query()
            ->where('account_type', \App\Enums\AccountType::Photographer)
            ->whereHas('photographerApplication', fn ($q) =>
                $q->where('status', \App\Enums\PhotographerApplicationStatus::Approved)
            )
            ->with([
                'photographerProfile',
                'photographerApplication',
                'portfolioImages',
                'packages',
                'addOns',
                'paymentConfig',
                'reviews.client',
            ])
            ->addSelect(['favorites_count' => FavoritePhotographer::selectRaw('count(*)')
                ->whereColumn('photographer_id', 'users.id')
            ])
            ->withCount(['reviews as reviews_count'])
            ->withAvg('reviews', 'rating')
            ->orderByDesc('reviews_avg_rating')
            ->orderByDesc('reviews_count')
            ->get()
            ->filter(fn ($photographer) => $bookabilityService->isBookable($photographer))
            ->take(5)
            ->values();

        return $this->success(PhotographerPublicProfileResource::collection($photographers));
    }
}